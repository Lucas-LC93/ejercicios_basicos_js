//Contador de repeticiones: Crea una función que nos devuelva el número de veces que se repite cada una de las palabras que lo conforma.Por ejemplo, que devuelva: code:4, repeat: 1, eat: 1,...

const words = [
  'code',
  'repeat',
  'eat',
  'sleep',
  'code',
  'enjoy',
  'sleep',
  'code',
  'enjoy',
  'sleep',
  'code'
];
function repeatCounter(list) {
 let contador = {};

  for (let i = 0; i < list.length; i++) {
    let palabra = list[i];

    if (contador[palabra]) {
      contador[palabra]++;
    } else {
      contador[palabra] = 1;
    }
   }
  for (let palabra in contador) {
    console.log(`${palabra}: ${contador[palabra]}`);
  }
}
repeatCounter(words);