//Buscador de nombres: Crea una función que reciba por parámetro un array y el valor que desea comprobar que existe dentro de dicho array. Esta función comprueba si existe el elemento, y en caso de que exista nos devuelve un true y la posición de dicho elemento y por la contra un false.

const names = [
  'Peter',
  'Steve',
  'Tony',
  'Natasha',
  'Clint',
  'Logan',
  'Xabier',
  'Bruce',
  'Peggy',
  'Jessica',
  'Marc'
];
nameFinder(names, "Tony");   
nameFinder(names, "Lucas"); 

function nameFinder(nameList, value) {
  // ver si el valor existe en el array
  if (nameList.includes(value)) {
    // posición
    let position = nameList.indexOf(value);

    console.log("La posición es:", position, true);
  } else {
    console.log("No existe",false);
  }
}
