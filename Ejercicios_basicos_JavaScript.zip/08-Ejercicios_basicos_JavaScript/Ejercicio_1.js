// 1. Defino mi superhéroe favorito
let miSuperheroeFavorito = "Hulk";

// 2. Defino un numero favorito
let numeroFavorito = 50;

// 3. Defino las dimensiones
let altura = 5;
let longitud = 10;

// 4. Calculo la suma de altura y longitud
let suma = altura + longitud;

// 5. Imprimo todas las variables en la consola
console.log("Mi superhéroe favorito es:", miSuperheroeFavorito);
console.log("Mi numero favorito es:", numeroFavorito);
console.log("La altura es:", altura);
console.log("La longitud es:", longitud);
console.log("La suma de altura y longitud es:", suma);